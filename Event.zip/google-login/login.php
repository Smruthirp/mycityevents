<?php
    require_once "config.php";

	if (isset($_SESSION['access_token'])) {
		header('Location: ../index.php');
		exit();
	}

	$loginURL = $gClient->createAuthUrl();
?>
<?php
    // require_once "../FacebookLogin/config.php";

    if (isset($_SESSION['access_token2'])) {
        header('Location: ../index.php');
        exit();
    }

    $redirectURL = "http://localhost/Login/FacebookLogin/fb-callback.php";
    $permissions = ['email'];
    $loginURL2 = $helper->getLoginUrl($redirectURL, $permissions);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login with Google or Facebook</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
<style type="text/css">

    *{margin: 0;}
    
a img{
    width: 230px;
    cursor: pointer;
    box-shadow: 0 0 5px #ccc;
}

header{
    height: 70px;
    box-shadow: 0 0 5px #ccc;
}
header img{
    float: left;
    width: 100px;
    box-shadow: none;
    padding-left: 20px;
}

h4{
    text-align: center;
    /*font-weight: bolder;*/
    font-family: sans-serif;
    font-size: 25px;
    color: #131630;
    font-family: 'Roboto', sans-serif;
    padding-top: 20px;
}
.line{
    background: linear-gradient(to right, #bf3131, #4149a3);
    height: 4px;
    width: 50%;
    margin-left: auto;
    margin-right: auto;
}

</style>

</head>
<body>
<header>
    <a href="../index.php" class="logo"><img src="../img/mylogo.png"></a>
</header>

    <h4>Welcome to My City Events. Please Sign in to continue</h4>
    <div class="line"></div>
    <div class="container" style="margin-top: 100px">

<center>
    <a onclick="window.location = '<?php echo $loginURL ?>';" class="btn"><img src="../img/google-sign.png"></a>
    <a onclick="window.location = '<?php echo $loginURL2 ?>';" class="btn"><img src="../img/facebook-login.png"></a>
</center>

    </div>
    
</body>
</html>