<?php
	session_start();
	require_once "GoogleAPI/vendor/autoload.php";
	$gClient = new Google_Client();
	$gClient->setClientId("296098573786-qkbt9ass70nu624mq7tt0gbmpdjo8kkg.apps.googleusercontent.com");
	$gClient->setClientSecret("gyo091LmpdENl-Pr2G62vKHi");
	$gClient->setApplicationName("My city events");
	$gClient->setRedirectUri("http://localhost/Login/login/g-callback.php");
	$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");
?>
