<?php $connect = mysqli_connect("localhost", "root", "", "responses"); ?>

<!DOCTYPE html>
<html>
<head>
<title>Admin | My City Events</title>
<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

<style type="text/css">
*{margin: 0;}
body{
	font-family: 'Roboto', sans-serif;
	scroll-behavior: smooth;
}	

header{
	background: #efb881;
	height: 80px;
	position: fixed;
	width: 100%;
	z-index: 1000;
}
header img{
	width: 100px;
	padding-left: 20px;
}
nav{
	position: fixed;
	background: #FFF;
	width: 100%;
	box-shadow: 0 0 5px #ccc;
	height: 50px;
	margin-top: 80px;
}

ul a li{
	list-style: none;
	float: left;
	background: #eee;
	margin: 10px;
	padding: 7px;
	border-radius: 50px;
	color: #333;
	width: 110px;
	text-align: center;
	font-size: 14px;
}
ul a li:hover, ul a li:focus{
	background: #eda863;
	color: #FFF;
}
h3{
	font-weight: normal;
	font-family: 'Raleway', sans-serif;
	font-size: 17px;
}
section{
	margin: 10px;
	padding: 10px;
	margin-bottom: 30px;
	border-radius: 3px;
	box-shadow: 0 0 5px #ccc;
}

h4{
	text-transform: capitalize;
	font-family: 'Raleway', sans-serif;
	border-bottom: 2px solid #eda863;
	padding-bottom: 10px;
	margin-bottom: 10px;
}
table{
	border-collapse: collapse;
	width: 100%;
}
td, th{
	border: 1px solid #ccc;	
	text-align: left;
	padding: 7px;
}
th{
	background: #f4ecd0;
}

</style>

</head>
<body>

<header>
	<a href="index.php"><img src="../img/mylogo.png"></a>
</header>
<nav>
	<ul>
		<a href="#home"><li>Home</li></a>
		<a href="#bank-details"><li>Bank Details</li></a>
		<a href="#booking-history"><li>Booking History</li></a>
		<a href="#messages"><li>Messages</li></a>
	</ul>
</nav><br><br><br><br><br><br><br><br>

<section id="home">
	<h3>Hello Admin, Welcome to My City Events. </h3>
</section>

<!-- BANK DETAILS -->

<section id="bank-details">
	<h4>Organizer's bank details</h4>
<?php 
	
	echo '<table>
	<tr>
	<th>Name</th>
	<th>Account no.</th>
	<th>IFSC Code</th>
	<th>Bank Name</th>
	<th>Email</th>
	<th>Phone</th>
	</tr>';

	$query = "SELECT * FROM bankdetails ORDER BY name";
	$result = mysqli_query($connect, $query);
	while($row = mysqli_fetch_array($result)){

	echo '
	<tr>
	<td>'.$row['name'].'</td>
	<td>'.$row['account'].'</td>
	<td>'.$row['ifsc'].'</td>
	<td>'.$row['bank'].'</td>
	<td>'.$row['email'].'</td>
	<td>'.$row['phone'].'</td>
	</tr>
	';
}
echo "</table>";
 ?>

</section>

<!-- BOOKING HISTORY -->
<section id="booking-history">
	<h4>Ticket booking history</h4>
<?php 
	echo '<table>
	<tr>
	<th>User</th>
	<th>Phone</th>
	<th>Email</th>
	<th>Event</th>
	<th>Location</th>
	<th>Total Amount</th>
	<th>No. of Attendees</th>
	<th>Booking ID</th>
	<th>Order Id</th>
	<th>Event Date</th>
	<th>Booking Date</th>
	</tr>';
	

	$query = "SELECT * FROM bookingdetails ORDER BY bookingDate";
	$result = mysqli_query($connect, $query);
	while($row = mysqli_fetch_array($result)){

	echo'
	<tr>
	<td>'.$row['userName'].'</td>
	<td>'.$row['userPhone'].'</td>
	<td>'.$row['userEmail'].'</td>
	<td>'.$row['eventName'].'</td>
	<td>'.$row['eventLocation'].'</td>
	<td>'.$row['ticketAmount'].'</td>
	<td>'.$row['attendees'].'</td>
	<td>'.$row['bookingId'].'</td>
	<td>'.$row['orderId'].'</td>
	<td>'.$row['eventDate'].'</td>
	<td>'.$row['bookingDate'].'</td>
	</tr>
	';
}
echo "</table>";
 ?>

</section>


<!-- MESSAGES -->
<section id="messages">
	<h4>My Messages</h4>
<?php 
	echo '<table>
	<tr>
	<th>Name</th>
	<th>Email</th>
	<th>Message</th>
	</tr>';
	

	$query = "SELECT * FROM contact_us ORDER BY id";
	$result = mysqli_query($connect, $query);
	while($row = mysqli_fetch_array($result)){

	echo'
	<tr>
	<td>'.$row['name'].'</td>
	<td>'.$row['email'].'</td>
	<td>'.$row['message'].'</td>
	</tr>
	';
}
echo "</table>";
 ?>

</section>


</body>
</html>