<?php $connect = mysqli_connect("localhost", "root", "", "responses"); ?>
<?php
require_once('../location/geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
?>

<!DOCTYPE html>
<html>
<head>
	<title>My City Event</title>
<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Philosopher" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/style.css">
<style type="text/css">
	.no-events{
		padding: 20px;
	}
	footer{
		position: absolute;
		bottom: 0;
		width: 100%;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		$('.mylocation').click(function(){
			$('.nearby').toggle();
		});
		$('.profileimg').click(function(){
			$('.mydetails').toggle();
		});
		
	});
</script>


</head>
<body>
<!-- HEADER PART -->
 <header>
  <a href="../index.php"><img src="../img/mylogo.png" draggable="false" style="width:85px; float: left; padding-left: 15px; height: 60px;"></a>

	<form method="POST">
		<input type="text" name="search" class="event_search" required placeholder="Search an Event, Organiser or Location..">
		<button type="submit" name="submit-search" class="event_submit">Search</button>
	</form>

	<div class="dropdown">
	  <button onclick="myFunction()" class="dropbtn">Organizers<i class="fa fa-angle-down"></i></button>
	  <div id="myDropdown" class="dropdown-content">
	    <a href="create.php" target="_blank">Create Event</a>
	    <a href="how-it-works.php" target="_blank">How it Works</a>
	    <a href="faq.php" target="_blank">FAQs</a>
	  </div>
	</div>

 <button class="mylocation"><?php echo "$geoplugin->city";?><i class="fa fa-angle-down"></i></button>
<div class="nearby">
	<p>Cities near <?php echo "$geoplugin->city";?></p>
	<?php 

	$nearby = $geoplugin->nearby();

if ( isset($nearby[0]['geoplugin_place']) ) {
	foreach ( $nearby as $key => $array ) {

		echo '<a href="city.php?sel_city='.$array['geoplugin_place'].'"><p>'.$array['geoplugin_place'].'</p></a>';
	}
}

 ?>

</div>
<?php
session_start();

if (!isset($_SESSION['access_token'])) {
	// header('Location: google-login/login.php');
	// exit();
	echo "<a href='../google-login/login.php' class='loginMe'>Login</a>";
	
}else{

echo "
<img class='profileimg' src=".$_SESSION['picture']." title=".$_SESSION['givenName'] .">
<div class='mydetails'>
	<div class='organiser' style='float: left; border-right: 1px solid #ccc; padding-right: 15px;'>
	<p style='border-bottom: 1px solid #ccc; padding-bottom: 10px;'>Organiser Profile</p>
	<p><b>".$_SESSION['givenName']. " ".$_SESSION['familyName']. "</b></p>
	<p>".$_SESSION['email'] ."</p><br>
	<a href='create.php' target='_blank'>Create Event</a>
	<a href='my-events.php' target='_blank'>My Events</a>
	<a href='payout-settings.php' target='_blank'>Payout Settings</a>
	</div>

	<div class='attendee' style='float: right; padding-right: 15px; text-align: right;'>
		<p style='border-bottom: 1px solid #ccc; padding-bottom: 10px;'>Attendee Profile</p>
		<p style='padding-bottom: 0px;'>".$_SESSION['givenName']." ".$_SESSION['familyName']."</p>
		<p>".$_SESSION['email']." </p><br>
		<a href='booking-history.php' target='_blank'>Booking History</a>
		<a href='../google-login/logout.php'>Logout</a>
	</div>
</div>
";}?>

</header>
<br><br><br><br>

<?php
ob_start();
include '../index.php';
ob_end_clean();
$connect = mysqli_connect("localhost", "root", "", "responses");

	if(isset($_GET['sel_city'])){
		$city = mysqli_real_escape_string($connect, $_GET['sel_city']);
		$sql = "SELECT * FROM image_table WHERE city LIKE'$city'";
		$result = mysqli_query($connect, $sql);
		$queryResult = mysqli_num_rows($result);
?>
<section>
	<h4>Events in <?php echo $city ?></h4>
<?php
	if($queryResult > 0){
		while($row = mysqli_fetch_assoc($result)){
		echo'<a href="details.php?sel_task='.$row["ID"].'"><div class="container">
				<img src="data:image/jpeg;base64,'.base64_encode($row['myimage'] ).'"/>
		<p class="details">'.$row['event'].' event in '.$row['city'].'</p>
		<p class="date">'.$stDate.'</p>
		</div></a>';
		}
		}else{
			echo "<p class='no-events'>No events found in $city</p>";
		}
	}

?>
</section>
<!-- FOOTER PART -->
<footer>
	<a href="about.php" target="_blank">About</a>
	<a href="team.php" target="_blank">Team</a>
	<a href="terms.php" target="_blank">Terms of service</a>
	<a href="privary-policy.php" target="_blank">Privacy Policy</a>
	<a href="pricing.php" target="_blank">Pricing</a>
	<a href="contact.php" target="_blank">Contact us</a>
	<img src="../img/mylogo.png" draggable="false" style="width:130px; float: right; padding-right: 30px;">
	<div class="copyright">
		© Copyright 2019. All Rights Reserved.
	</div>
</footer>
<script>
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

</body>
</html>