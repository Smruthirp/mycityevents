<?php $connect = mysqli_connect("localhost", "root", "", "responses"); ?>
<?php
session_start();
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === "on")
	$link = "https";
else
	$link = "http";

$link .= "://";
$link .= $_SERVER['HTTP_HOST'];
$link .= $_SERVER['REQUEST_URI'];

?>

<!DOCTYPE html>
<html>
<head>
	<title>Event Details | My City Events</title>
<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<header>
  <a href="../index.php"><img src="../img/mylogo.png" draggable="false" style="width:85px; float: left; padding-left: 15px; height: 60px;"></a>


<?php 
if (!isset($_SESSION['access_token'])) {
	echo "<a href='google-login/login.php' class='loginMe'>Login</a>";
}

 else{
 	echo '


<img class="profileimg" src="'.$_SESSION['picture'] .'" title="'.$_SESSION['givenName'].'">
<div class="mydetails">
	<div class="organiser" style="float: left; border-right: 1px solid #ccc; padding-right: 15px;">
	<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;">Organiser Profile</p>
	<p style="border-bottom: none;"><b>'.$_SESSION['givenName']. ' ' .$_SESSION['familyName'] .'</b></p>
	<p style="border-bottom: none;">'.$_SESSION['email'] .'</p><br>
	<a href="create.php" target="_blank">Create Event</a>
	<a href="my-events.php" target="_blank">My Events</a>
	</div>

	<div class="attendee" style="float: right; padding-right: 15px; text-align: right;">
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;">Attendee Profile</p>
		<p style="border-bottom: none;">'.$_SESSION['givenName']. ' ' . $_SESSION['familyName'] .'</p>
		<p style="border-bottom: none;">'.$_SESSION['email'] .'</p><br>
		<a href="booking-history.php" target="_blank">Booking History</a>
		<a href="../google-login/logout.php">Logout</a>
	</div>


</div>
';}?>
</header>

<br><br><br><br>


<?php
ob_start();
include '../index.php';
ob_end_clean();
$connect = mysqli_connect("localhost", "root", "", "responses");
$OrganiserName="";
$OrganiserEmail="";
	if(isset($_GET['sel_task'])){
		$id = mysqli_real_escape_string($connect, $_GET['sel_task']);
		$sql = "SELECT * FROM image_table WHERE ID LIKE'$id'";
		$result = mysqli_query($connect, $sql);
		$queryResult = mysqli_num_rows($result);

	if($queryResult > 0){
		while($row = mysqli_fetch_assoc($result)){

		$eventId = $row['ID'];
		$event = $row['event'];
		// $user = $_SESSION['givenName'];
		$city = $row['city'];
		$location = $row['location'];
		// $email =  $_SESSION['email'];
		$OrganiserName = $row['user'];
		$OrganiserEmail = $row['myemail'];

		$adult = $row['adult'];
		$adult_seat = $row['adult_seat'];
		$children = $row['children'];
		$children_seat = $row['children_seat'];
		$couple = $row['couple'];
		$couple_seat = $row['couple_seat'];
		$avg = $adult+$children+$couple; 

		$sDate = $row['startDate'];
		$stDate = date("d M Y", strtotime($sDate));

		$eDate = $row['endDate'];
		$enDate = date("d M Y", strtotime($eDate));

		$sTime = $row['startTime'];
		$stTime = date("h:i a", strtotime($sTime));

		$eTime = $row['endTime'];
		$enTime = date("h:i a", strtotime($eTime));
		
		echo' 
		<section><img class="image" src="data:image/jpeg;base64,'.base64_encode($row['myimage']).'"/>
		<div class="text"><h2>'.$row['event'].'</h2>
		<p style="display: inline-block;float: left; margin-right: 20px;"><button>From</button><i class="fa fa-calendar"></i>'.$stDate.'</p>

		<p><button>Till</button><i class="fa fa-calendar"></i>'.$enDate.'<a target="_blank" href="https://www.google.com/calendar/render?action=TEMPLATE&amp;text='.$row['event']. ' Event &amp;dates=20190201T210000Z/20300101T205900Z&amp;details='.$row['description']. '&amp;location='.$row['location'].'&amp;sprop=&amp;sprop=name:" class="view_map">ADD TO MY GOOGLE CALANDER</a></p><br>

		<p style="display: inline-block;float: left; margin-right: 20px;"><button>At</button><i class="fa fa-clock-o"></i>'.$stTime.'</p>
		<p><button>/</button><i class="fa fa-clock-o"></i>'.$enTime.'</p><br>

		<p><button>Venue</button><i class="fa fa-map-marker"></i> '.$row['location'].' <a target="_blank" href="https://www.google.co.in/maps?q='.$row['location'].'" class="view_map">VIEW IN GOOGLE MAP</a></p><br>
		<p><button>Created by</button><i class="fa fa-user"></i> '.$row['user'].'</p><br>
		</div>
		
		</section>';

		if($avg > 0){

			$taxMessage = "";
			$taxCharge="";
				if($row['tax'] == 'No'){
					$taxCharge = 2;
				$taxMessage = ('2 % convenience charges will be charged on this booking.');

			}else{
				$taxMessage ="";
				$taxCharge=0;
			}
			echo "
		<section><div style='border-bottom: 1px dashed #ccc; margin-bottom: 10px; padding-bottom: 5px;'>$taxMessage</div>
		<table>
			<tr>
			<th>Ticket Type</th>
			<th>Ticket Price</th>
			<th>Seat Quantity</th>
			</tr>

			<tr>
			<td>Adult</td>
			<td>".$row['adult']."</td>
			<td><script>document.write('<select id=".'mySelect1'." onchange=".'myFunction()'.">');
			for(var i=0; i<=$adult_seat; i++){
				document.write('<option>'+i+'</option>');
			}
			document.write('</select>')</script></td>
			</tr>

			<tr>
			<td>Children</td>
			<td>".$row['children']."</td>
			<td><script>document.write('<select id=".'mySelect2'." onchange=".'myFunction()'.">')
			for(var j=0; j<=$children_seat; j++){
				document.write('<option>'+j+'</option>');
			}
			document.write('</select>')</script></td>
			</tr>

			<tr>
			<td>Couple</td>
			<td>".$row['couple']."</td>
			<td><script>document.write('<select id=".'mySelect3'." onchange=".'myFunction()'.">')
			for(var k=0; k<=$couple_seat; k++){
				document.write('<option>'+k+'</option>');
			}
			document.write('</select>')</script></td>
			<script>
			function myFunction(){
			var x = document.getElementById('mySelect1').value;
			var y = document.getElementById('mySelect2').value;
			var z = document.getElementById('mySelect3').value;


			var pent = document.getElementById('para').innerHTML = x*".$adult." + y*".$children." + z*".$couple.";
			var perCnt = document.getElementById('para3').innerHTML = $taxCharge/100*pent ;
			document.getElementById('para4').innerHTML = pent+perCnt ;
			document.getElementById('para2').innerHTML = 'Adult: '+ x + '. Children: ' + y + '. Couple: ' + z + '.';  

			document.getElementById('adultCount').innerHTML = x;  
			document.getElementById('childrenCount').innerHTML = y;  
			document.getElementById('coupleCount').innerHTML = z;  
		}
			</script>


			</tr>
		</table>

		<form action='checkout.php' method='POST'>
			<br> <p class='ttl'>Ticket amount total Rs.: </p><textarea id='para' readonly name='ticketAmount'></textarea>
			<br> <p class='ttl'>Convenience charges $taxCharge %:  </p><textarea id='para3' readonly name='percent'></textarea>
			<br> <p class='ttl'>Total amount Rs.:  </p><textarea id='para4' readonly name='totalAmount'></textarea><br><hr>

			<textarea id='para2' readonly name='participant' style='display: none;'></textarea><br>
			<img src='../img/paytm.png' class='payImg'>
			<img src='../img/mastercard.png' class='payImg' style='margin-top: 10px; height: 35px;'><br><br><br><br>
			<label for='phn'>Enter your phone: </label><br>
			<input type='number'required name='phone' placeholder='Ex: 9999999999' min='10' style='width: 250px;margin-top: 10px;' id='phn'><br><br><br>
			
			<input type='text' value='$event' name='event' style='display: none;'>
			
			<input type='text' value='$location' name='location' style='display: none;'>
			<input type='text' value='$stDate' name='sDate' style='display: none;'>
			<input type='text' value='$stTime' name='sTime' style='display: none;'>

			<input type='text' value='$eventId' name='eventId' style='display: none;'>

			<input type='text' value='$adult_seat' name='adult_seat' style='display: none;'>
			<input type='text' value='$children_seat' name='children_seat' style='display: none;'>
			<input type='text' value='$couple_seat' name='couple_seat' style='display: none;'>

			<textarea id='adultCount' readonly name='adultCount' style='display: none;'></textarea><br>
			<textarea id='childrenCount' readonly name='childrenCount' style='display: none;'></textarea><br>
			<textarea id='coupleCount' readonly name='coupleCount' style='display: none;'></textarea><br>


			<input type='submit' class='bookNow' value='Book Now' style='margin-top:-50px; width:150px;'>
		</form>
			</section>

			";
		}else{
			echo "<section><p>This event is Free.</p></section>";
		}

		echo' 
		<section><img class="image_banner" src="data:image/jpeg;base64,'.base64_encode($row['myimage']).'"/>

		<h3 class="description_heading">Event Description</h3>
		<p class="description_para">'.$row['description'].'</p>
		
		</section>';

		}
		}else{
			echo "";
		}
	}

?>


<section>
	<h4>Similar events in <?php echo "$city"; ?></h4>
	<?php 
	$query = "SELECT * FROM image_table WHERE city = '$city' ORDER BY id ASC LIMIT 2";
	$result = mysqli_query($connect, $query);
	while($row = mysqli_fetch_array($result)){

	$sDate = $row['startDate'];
	$stDate = date("l, M d", strtotime($sDate));
	echo '
	<div class="container2"><a href="details.php?sel_task='.$row["ID"].'" style="text-decoration :none;">
	<img src="data:image/jpeg;base64,'.base64_encode($row['myimage'] ).'"/>
	<p style="color: #333; padding: 10px; border: none;">'.$row['event'].' event in '.$row['city'].'</p>
	<p style="font-size: 13px; border: 1px solid green; color: green; width: auto;display: inline-block;margin: 5px; padding: 3px; border-radius:2px;">'.$stDate.'</p>
	</a></div>
	';
}
 ?>
</section>

<!-- ASIDE -->
<aside>
	<h4>Share Event</h4>
	<input type="text" name="myUrl" style="width: 90%;" value="<?php echo $link; ?>" onclick="this.select()"><br><br><br>
	<a href="http://www.facebook.com/sharer.php?s=100&p[title]=<?php echo $row['event']?>&p[summary]=<?php echo $row['description']?>&p[url]=<?php echo $link ?>&p[images][0]=<?php echo $row['myimage']?>" target="_blank" style="color: #fff; padding: 5px; margin: 10px;font-size: 13px;border-radius: 2px; text-decoration: none; background: #3b5998;">Share on Facebook</a>

	<a href="https://twitter.com/intent/tweet?text=<?php echo $link; ?>" target="_blank" style="color: #fff; padding: 5px; margin: 10px;font-size: 13px;border-radius: 2px; text-decoration: none; background: #00acee;">Share on Twitter</a>
</aside>

<aside>
	<h4>Organizer Details</h4>
	<?php echo "<p style='padding-left: 10px;'><b>Name:</b> ". $OrganiserName."</p>";?><br>
	<?php echo "<p style='padding-left: 10px;'><b>Email:</b> ".$OrganiserEmail. "<br><br><a href='mailto:$OrganiserEmail'>Email Organizer</a></p>";?>


</aside>

<!-- FOOTER PART -->
<footer>
	<a href="about.php" target="_blank">About</a>
	<a href="team.php" target="_blank">Team</a>
	<a href="terms.php" target="_blank">Terms of service</a>
	<a href="privary-policy.php" target="_blank">Privacy Policy</a>
	<a href="pricing.php" target="_blank">Pricing</a>
	<a href="contact.php" target="_blank">Contact us</a>
	<img src="../img/mylogo.png" draggable="false" style="width:130px; float: right; padding-right: 30px;">
	<div class="copyright">
		© Copyright 2019. All Rights Reserved.
	</div>
</footer>

<script type="text/javascript">
$(document).ready(function(){
    
    $('.mylocation').click( function(e) {
        e.preventDefault();
        e.stopPropagation();
        $('.nearby').toggle();
    });
    $('.nearby').click( function(e) {
        e.stopPropagation();
    });
    $('body').click( function() {
        $('.nearby').hide();
    });

// FOR PROFILE
    $('.profileimg').click( function(e) {
    e.preventDefault();
    e.stopPropagation();
    $('.mydetails').toggle();

    });
    $('.mydetails').click( function(e) {
        e.stopPropagation();
    });
    $('body').click( function() {
        $('.mydetails').hide();
    });
    
});

</script>
</body>
</html>