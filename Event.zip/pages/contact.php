<?php 
$connect = mysqli_connect("localhost", "root", "", "responses");
$msg = "";
if(isset($_POST["insert"]))
{
	$name = $_POST['name'];
	$email = $_POST['email'];
	$message = $_POST['message'];

	$query = "INSERT INTO contact_us(name, email,message) VALUES ('$name', '$email', '$message')";
	if(mysqli_query($connect, $query))
	{
		$msg = '<p>Thank you for your message, we will get back to you soon. Go to home page <a href="../index.php">click here</a></p>';

	}
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Contact Us | My City Events</title>
	<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<style type="text/css">
*{margin: 0;}
body{
	font-family: 'Roboto', sans-serif;
	background: #f1f1f1;
	}
header{
	background: #FFF;
	position: fixed;
	width: 100%;
	height: 60px;
    box-shadow: 0 0 3px #000;
	}
header img{
	float: left;
	width: 80px;
	padding-left: 15px;
}
section{
	width: 90%;
	background: #fff;
	height: auto;
	padding: 25px;
	margin-top: 10px;
	border-radius: 2px;
	box-shadow: 0 0 5px #ccc;
	margin-bottom: 30px;
	margin-left: auto;
	margin-right: auto;
}
label{
	color: #505556;
}
input[type="text"],[type="email"]{
	outline: none;
	margin-bottom: 10px;
	border: 1px solid #bbb;
	border-radius: 2px;
	padding: 6px;
	width: 400px;
	font-size: 15px;
}
textarea{
	outline: none;
	width: 400px;
	height: 100px;
	padding: 6px;
	font-size: 15px;
	border: 1px solid #bbb;
	font-family: 'Roboto', sans-serif; 
}
input[type="submit"]{
	outline: none;
	border: none;
	background: #3fa7c6;
	color: #FFF;
	padding: 7px;
	text-transform: uppercase;
	width: 200px;
	border-radius: 1px; 
}
h1{
	font-family: 'Raleway', sans-serif;
	color: #3d526d;
	font-weight: bold;
	font-size: 20px;
	padding-bottom: 30px;
}
p{
	background: #1c5b2f;
	color: #fff;
	padding: 10px;
	border-radius: 2px;
	margin-bottom: 10px;
}
p a{
	color: #fff;
	text-decoration: underline;
}
footer{
	background: #251830;
	height: 150px;
	padding: 30px 0 0 0;
	border-top: 2px solid #333;
}
footer a{
	text-decoration: none;
	color: #f1f1f1;
	display: inline-block;
	margin: 5px;
	font-family: 'Raleway', sans-serif;
	font-weight: normal;
	padding: 5px;
	font-size: 14px;
}
footer a:hover{
	text-decoration: underline;
}
.copyright{
	background: #130a1c;
	padding: 15px;
	margin-top: 70px;
	color: #aaa;
	font-size: 13px;
}

	</style>
</head>
<body>

<header>
	<a href="../index.php"><img src="../img/mylogo.png"></a>
</header><br><br><br><br>

<section>
	<?php echo "$msg"; ?>
	<h1>Contact us</h1>	
<form method="post">
	<label for="name">Name: </label><br>
	<input type="text" name="name" placeholder="Your name.." required /><br><br>

	<label for="email">Email: </label><br>
	<input type="email" name="email" placeholder="Your email.."  required/><br><br>

	<label for="message">Message: </label><br>
	<textarea name="message" placeholder="Type your message here.."  required/></textarea><br><br>

	<input type="submit" name="insert" value="Submit">

</form>
</section>

<!-- FOOTER PART -->
<footer>
	<a href="about.php" target="_blank">About</a>
	<a href="team.php" target="_blank">Team</a>
	<a href="terms.php" target="_blank">Terms of service</a>
	<a href="privary-policy.php" target="_blank">Privacy Policy</a>
	<a href="pricing.php" target="_blank">Pricing</a>
	<a href="contact.php" target="_blank">Contact us</a>
	<img src="../img/mylogo.png" draggable="false" style="width:130px; float: right; padding-right: 30px;">
	<div class="copyright">
		© Copyright 2019. All Rights Reserved.
	</div>
</footer>


</body>
</html>