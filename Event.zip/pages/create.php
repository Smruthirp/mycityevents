<?php
session_start();
if (!isset($_SESSION['access_token'])) {
	header('Location: ../google-login/login.php');
	exit();
}
?>

<?php 
$connect = mysqli_connect("localhost", "root", "", "responses");
$msg = "";
if(isset($_POST["insert"]))
{
	// $organiser = $_SESSION['username']; 
	$myemail = $_SESSION['email'];
	$user  = $_SESSION['givenName'];

	$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
	$event = $_POST['event'];
	$category = $_POST['category'];
	$city = $_POST['city'];
	$location = $_POST['location'];
	$startDate = $_POST['startDate'];
	$endDate = $_POST['endDate'];
	$startTime = $_POST['startTime'];
	$endTime = $_POST['endTime'];
	$description = $_POST['description'];

// PAYMENT
	$adult = $_POST['adult'];
	$adult_seat = $_POST['adult_seat'];
	$children = $_POST['children'];
	$children_seat = $_POST['children_seat'];
	$couple = $_POST['couple'];
	$couple_seat = $_POST['couple_seat'];
	$tax = $_POST['tax'];

	$query = "INSERT INTO image_table(event, myimage, message, city, location, startDate, endDate, startTime, endTime, description, myemail, user, adult, adult_seat, children, children_seat, couple, couple_seat, tax) VALUES ('$event', '$file', '$category', '$city', '$location', '$startDate', '$endDate', '$startTime', '$endTime', '$description', '$myemail', '$user', '$adult', '$adult_seat', '$children', '$children_seat', '$couple', '$couple_seat', '$tax')";
	if(mysqli_query($connect, $query))
	{
		$msg = 'Event created. Go to main page <a href="../index.php">click here</a>';
	}
}
 ?>

<!DOCTYPE html>
<html>
<head>
<title>Create an Event | My City Events</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Philosopher" rel="stylesheet">
<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
<style>
*{margin: 0;}
body{
	font-family: 'Roboto', sans-serif;
	background: #f1f1f1;
	}
header{
	background: #FFF;
	position: fixed;
	width: 100%;
	height: 60px;
	z-index: 1000;
	background: /* gradient can be an image */
    linear-gradient(to left, #54aac9 0%, #54aac9 12%, #4dc170 47%, #54aac9 100%)left bottom #fff no-repeat; background-size:100% 3px ;
    box-shadow: 0 0 3px #000;
	}
header h1 a{
	text-decoration: none;
	color: #000;
	float: left;
	font-family: 'Philosopher', sans-serif;
	font-size: 24px;
	padding-left: 15px;
	line-height: 50px;
}section{
	margin-left: auto;
	margin-right: auto;
	margin-top: 30px;
	width: 80%;
	padding: 30px;
	box-shadow: 0 0 5px #ccc;
	background: #FFF;
	border-radius: 3px;
	}
input[type="text"],[type="date"],[type="time"],[type="file"],[type="submit"],[type="number"]{
	outline: none;
	width: 400px;
	padding: 7px;
	margin-top: 8px;
	font-size: 14px;
	border: 1px solid #ccc;
	border-radius: 2px;
	}
input:focus{
	border: 1px solid #000;
	}
#insert{
	background: #3f5268;
	color: #d0dae5;
	font-size: 17px;
	width: 418px;
	}
select{
	outline: none;
	width: 415px;
	padding: 7px;
	margin-top: 8px;
	font-size: 14px;
	border: 1px solid #ccc;
	border-radius: 2px;
	}
textarea{
	outline: none;
	resize: none;
	width: 400px;
	padding: 7px;
	border-right: 2px;
	height: 200px;
	border: 1px solid #ccc;
	font-size: 16px;
	margin-top: 5px;
	font-family: 'Roboto', sans-serif;
	}
textarea:focus{
	border: 1px solid #000;
	}
input[type='date'], input[type='time']{
	font-family: sans-serif;
	}
input[type="number"]::-webkit-inner-spin-button,input[type="number"]::-webkit-outer-spin-button{
	-webkit-appearance: none; 
}
#event_created{
	margin-bottom: 20px;
	padding-bottom: 10px;
	color: green;
	border-bottom: 1px solid #ddd;
	}
.inormation{
	margin-bottom: 15px;
	width: 120px;
	margin-left: -30px;
	padding: 5px;
	color: #fff;
	font-size: 14px;
	background: linear-gradient(to right, #533e59, #fff);
}
#pay{
	display: none;
}
input[type="radio"]{
	margin-right: 20px;
}
label{
	padding-right: 5px;
}

</style>
<script type="text/javascript">
	$(document).ready(function(){
		$("#no").click(function(){
			$("#pay").css("display", "block");

		});
		$("#yes").click(function(){
			$("#pay").css("display", "none");

		})
	})
</script>

<script>
	function getISODate(){
	  var d = new Date();
	  return d.getFullYear() + '-' + 
          ('0' + (d.getMonth()+1)).slice(-2) + '-' +
          ('0' + d.getDate()).slice(-2);
		}
	  window.onload = function() {
	  document.getElementById('startDate').setAttribute('min',getISODate());
	  document.getElementById('endTimeDate').setAttribute('min',getISODate());
	}
</script>
</head>
<body>

<header>
	<a href="../index.php"><img src="../img/mylogo.png" draggable="false" style="width:85px; float: left; padding-left: 15px; height: 60px;"></a>
</header>
<br>
<br>
<br>
<br>
<section>
	<p id="event_created"><?php echo $msg; ?></p>

<form method="post" enctype="multipart/form-data">
<div class="inormation">
	Event Details
</div>
	<label for="event">Enter event name: </label><br>
	<input type="text" name="event" placeholder="Event" id="event"/><br><br>

	<label for="category">Select a category: </label><br>
	<select id="category" name="category">
		<option value="">All Events</option>
		<option value="Concerts">Concerts</option>
		<option value="Parties">Parties</option>
		<option value="Exhibitions">Exhibitions</option>
		<option value="Sports">Sports</option>
		<option value="Arts & Theatre">Arts & Theatre</option>
		<option value="Advebtures">Advebtures</option>
		<option value="Food & Drinks">Food & Drinks</option>
		<option value="Health & Wellness">Health & Wellness</option>
		<option value="Festivals">Festivals</option>
		<option value="Meetups">Meetups</option>
		<option value="Business">Business</option>
	</select>
	<br><br>
<!-- 	<label for="organiser">Enter organiser name: </label><br>
	<input type="text" name="user" placeholder="Organiser" id="organiser" /><br><br> -->
		
	<label for="city">Enter city name: </label><br>
	<input type="text" name="city" placeholder="City" id="city" /><br><br>

	<label for="pac-input">Enter full address: </label><br>

	<div id="map"></div>
    <input id="pac-input" name="location" class="controls" type="text" placeholder="Address"><br><br><br>

    <label for="startDate">Select event start date: </label><br>
    <input type="date" name="startDate" id="startDate"><br><br>

	    <label for="endDate">Select event end date: </label><br>
    <input type="date" name="endDate" id="endDate"><br><br>

    <label for="startTime">Select event start time: </label><br>
    <input type="time" name="startTime" id="startTime"><br><br>

    <label for="endTime">Select event end time: </label><br>
    <input type="time" name="endTime" id="endTime"><br><br>

	<label for="image">Select an image: </label><br>
	<input type="file" name="image" id="image" /><br><br>

	<label for="description">Describe your event: </label><br>
	<textarea name="description" id="description" placeholder="Tell people more about your event.." /></textarea><br><br>

	<div class="inormation">
	Payment Details
	</div>
	
	<p>Is the event for free?</p><br>
	<label for="yes">Yes</label><input type="radio" name="payment" id="yes">
	<label for="no">No</label><input type="radio" name="payment" id="no">
	<br><br>
	
	<div id="pay">
	<label for="adult">Adult ticket amount</label><br>
	<input type="number" name="adult" id="adult" placeholder="Ex: 500" min="0"><br><br>
	
	<label for="adult_seat">Adult total seats</label><br>
	<input type="number" name="adult_seat" id="adult_seat" placeholder="Ex: 100" min="0"><br><br>

	<label for="children">Children ticket amount</label><br>
	<input type="number" name="children" id="children" placeholder="Ex: 500" min="0"><br><br>

	<label for="children_seat">Children total seats</label><br>
	<input type="number" name="children_seat" id="children_seat" placeholder="Ex: 100" min="0"><br><br>

	<label for="couple">Couple ticket amount</label><br>
	<input type="number" name="couple" id="couple" placeholder="Ex: 500" min="0"><br><br>

	<label for="couple_seat">Couple total seats</label><br>
	<input type="number" name="couple_seat" id="couple_seat" placeholder="Ex: 100" min="0">

	<br><br><br>
	<p>Do you agree to pay 2 % of convenience fees to My City Events as commision?</p><br>
	<label for="agree">Yes i agree</label> 
	 <input type="radio" name="tax" value="Yes" id="agree">
	<label for="disagree">No, Charge from customer while ticketing </label>
	 <input type="radio" name="tax" value="No" id="disagree">
	
	<br><br>

	</div>

<input type="submit" name="insert" id="insert" value="Post Event" class="btn">

</form>
</section>
</body>
</html>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDU5mKV4oCZcxKQfOka5Mz5LlcqS3eB2YU&libraries=places&signed_in=true&callback=initMap"></script>
<script src="../js/index.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('#insert').click(function(){
		var image_name = $('#image').val();
		if(image_name == ''){
			alert("Please select image");
			return false;
		}
		else {
			var extension = $('#image').val().split('.').pop().toLowerCase();
			if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
			{
				alert('Invalid image file');
				$('#image').val('');

				return false;
			}
		}
	});
});
</script>