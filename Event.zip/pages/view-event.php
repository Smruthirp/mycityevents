<?php $connect = mysqli_connect("localhost", "root", "", "responses"); ?>
<?php
session_start();

require_once('../location/geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();

if (!isset($_SESSION['access_token'])) {
	header('Location: ../google-login/login.php');
	exit();
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Event Details | My City Events</title>
<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style type="text/css">
/*footer{
	position: absolute;
	bottom: 0;
	width: 100%;
}*/	
section h1{
	color: #200e26;
	text-transform: uppercase;
	font-size: 20px;
	padding-left: 50px;
	padding-bottom: 15px;
	font-weight: normal;
	margin-bottom: 20px;
	border-bottom: 2px solid #ccc;
}
section p{
	padding: 15px;
	border-bottom: 1px dotted #ddd;
}
.back{
	text-decoration: none;
	padding: 5px;
	display: inline-block;
	margin-left: 20px;
	color: #333;
	text-transform: uppercase;
	font-size: 14px;
	font-weight: bold;
	background: #fff;
	border: 2px solid #333;
	box-shadow: 0 0 2px #333;
	margin-top: 35px;
}

</style>

<script type="text/javascript">
$(document).ready(function(){
    
    $('.mylocation').click( function(e) {
        e.preventDefault();
        e.stopPropagation();
        $('.nearby').toggle();
    });
    $('.nearby').click( function(e) {
        e.stopPropagation();
    });
    $('body').click( function() {
        $('.nearby').hide();
    });

// FOR PROFILE
    $('.profileimg').click( function(e) {
    e.preventDefault();
    e.stopPropagation();
    $('.mydetails').toggle();

    });
    $('.mydetails').click( function(e) {
        e.stopPropagation();
    });
    $('body').click( function() {
        $('.mydetails').hide();
    });
    
});

</script>

</head>
<body>

 <header>
  <a href="index.php"><img src="../img/mylogo.png" draggable="false" style="width:85px; float: left; padding-left: 15px; height: 60px;"></a>

	<form method="POST">
		<input type="text" name="search" class="event_search" required placeholder="Search an Event, Organiser or Location..">
		<button type="submit" name="submit-search" class="event_submit">Search</button>
	</form>

	<div class="dropdown">
	  <button onclick="myFunction()" class="dropbtn">Organizers<i class="fa fa-angle-down"></i></button>
	  <div id="myDropdown" class="dropdown-content">
	    <a href="create.php">Create Event</a>
	    <a href="how-it-works.php">How it Works</a>
	    <a href="faq.php">FAQs</a>
	  </div>
	</div>

 <button class="mylocation"><?php echo "$geoplugin->city";?><i class="fa fa-angle-down"></i></button>
<div class="nearby">
	<p>Cities near <?php echo "$geoplugin->city";?></p>
	<?php 

	$nearby = $geoplugin->nearby();

if ( isset($nearby[0]['geoplugin_place']) ) {
	foreach ( $nearby as $key => $array ) {

		echo '<a href="city.php?sel_city='.$array['geoplugin_place'].'"><p>'.$array['geoplugin_place'].'</p></a>';
	}
}

 ?>

</div>
<img class="profileimg" src="<?php echo $_SESSION['picture'] ?>" title="<?php echo $_SESSION['givenName'] ?>">
<div class="mydetails">
	<div class="organiser" style="float: left; border-right: 1px solid #ccc; padding-right: 15px;">
	<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;">Organiser Profile</p>
	<p><b><?php echo $_SESSION['givenName']. ' ' ?><?php echo $_SESSION['familyName'] ?></b></p>
	<p><?php echo $_SESSION['email'] ?></p><br>
	<a href="create.php" target="_blank">Create Event</a>
	<a href="my-events.php" target="_blank">My Events</a>
	</div>

	<div class="attendee" style="float: right; padding-right: 15px; text-align: right;">
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;">Attendee Profile</p>
		<p style="padding-bottom: 0px;"><?php echo $_SESSION['givenName']. ' ' ?><?php echo $_SESSION['familyName'] ?></p>
		<p><?php echo $_SESSION['email'] ?></p><br>
		<a href="booking-history.php" target="_blank">Booking History</a>
		<a href="../google-login/logout.php">Logout</a>
	</div>


</div>
</header>

<br><br><br><br>

<?php
ob_start();
include 'booking-history.php';
ob_end_clean();

if(isset($_GET['sel_task'])){
	$id = mysqli_real_escape_string($connect, $_GET['sel_task']);

	$sql = "SELECT * FROM bookingdetails WHERE ID LIKE'$id'";
	$result = mysqli_query($connect, $sql);
	$queryResult = mysqli_num_rows($result);

	if($queryResult > 0){
		while($row = mysqli_fetch_assoc($result)){
	  echo "<section>
	  		<h1><b>".$row['eventName']."</b> - ".$row['eventDate']."</h1>
	  		<p><b>Location: </b>".$row['eventLocation']."</p>
	  		<p><b>Total amount: </b> ₹ ".$row['ticketAmount']."</p>
	  		<p><b>Total attendees: </b>".$row['attendees']."</p>
	  		<p><b>Booking id: </b>".$row['bookingId']."</p>
	  		<p><b>Event date: </b>".$row['eventDate']."</p>
	  		<p><b>Event start time: </b>".$row['startTime']."</p>
	  		<p><b>Booked on: </b>".$row['bookingDate']."</p>
	  		<a href='booking-history.php' class='back'>Back to booking history</a>
			</section>";
	}
}}
?>

<!-- FOOTER PART -->
<footer>
	<a href="about.php" target="_blank">About</a>
	<a href="team.php" target="_blank">Team</a>
	<a href="terms.php" target="_blank">Terms of service</a>
	<a href="privary-policy.php" target="_blank">Privacy Policy</a>
	<a href="pricing.php" target="_blank">Pricing</a>
	<a href="contact.php" target="_blank">Contact us</a>
	<img src="../img/mylogo.png" draggable="false" style="width:130px; float: right; padding-right: 30px;">
	<div class="copyright">
		© Copyright 2019. All Rights Reserved.
	</div>
</footer>

</body>
</html>