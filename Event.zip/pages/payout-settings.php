<?php $connect = mysqli_connect("localhost", "root", "", "responses"); ?>
<?php
require_once('../location/geoplugin.class.php');
$msg = "";
$geoplugin = new geoPlugin();
$geoplugin->locate();
?>

<?php
session_start();

if (!isset($_SESSION['access_token'])) {
	header('Location: ../google-login/login.php');
	exit();
}
?>

<?php 
if(isset($_POST["submit"]))
{

	$name = $_POST['name'];
	$account = $_POST['account'];
	$ifsc = $_POST['ifsc'];
	$bank = $_POST['bank'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];

	$query = "INSERT INTO bankdetails(name, account, ifsc, bank, email, phone) VALUES ('$name', '$account', '$ifsc', '$bank', '$email', '$phone')";
	if(mysqli_query($connect, $query))
	{
		$msg = '<span>Account details added. Go to main page <a href="../index.php">click here</a></span>';
	}
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Payout Settings | Organizers |  My City Events</title>
	<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Philosopher" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="../css/style.css">

<style type="text/css">
section{
	margin-top: 40px;
}
p{
	background: linear-gradient(to left, #306e7f, skyblue);
	color: #FFF;
	display: inline-block;
	position: relative;
	left: 50%;
	padding: 13px;
	margin-bottom: 10px;
	border-radius: 3px;
	transform: translateX(-50%);
}

table{
	margin-top: 60px;
	margin-left: auto;
	margin-right: auto;
}
h3{
	float: left;
	color: #000;
	font-size: 18px;
	font-weight: bold;
	margin-top: -20px;
	text-transform: uppercase;
}
input[type="number"]::-webkit-inner-spin-button,input[type="number"]::-webkit-outer-spin-button{
	-webkit-appearance: none; 
}
label{
	float: right;
	padding-right: 20px;
	padding-top: 10px;
}

input{
	outline: none;
	border-radius: 2px;
	border: 1px solid #ccc;
	padding: 6px;
	width: 300px;
	font-size: 14px;
	padding-top: 10px;
	padding-left: 20px;
	margin-top: 10px;
}
input[type="submit"]{
	background: #eaa40e;
	outline: none;
	color: #FFF;
	margin-top: 15px;
	font-weight: bold;
	text-transform: uppercase;
	width: 100px;
	border: none;
	padding: 5px;
	float: right;
}
footer{
	background: #251830;
	height: 150px;
	padding: 30px 0 0 0;
	border-top: 2px solid #333;
}
footer a{
	text-decoration: none;
	color: #f1f1f1;
	display: inline-block;
	margin: 5px;
	font-family: 'Raleway', sans-serif;
	font-weight: normal;
	padding: 5px;
	font-size: 14px;
}
footer a:hover{
	text-decoration: underline;
}
.copyright{
	background: #130a1c;
	padding: 15px;
	margin-top: 70px;
	color: #aaa;
	font-size: 13px;
}



</style>
</head>
<body>

	<!-- HEADER PART -->
 <header>
  <a href="index.php"><img src="../img/mylogo.png" draggable="false" style="width:85px; float: left; padding-left: 15px; height: 60px;"></a>

	<form method="POST">
		<input type="text" name="search" class="event_search" required placeholder="Search an Event, Organiser or Location..">
		<button type="submit" name="submit-search" class="event_submit">Search</button>
	</form>

	<div class="dropdown">
	  <button onclick="myFunction()" class="dropbtn">Organizers<i class="fa fa-angle-down"></i></button>
	  <div id="myDropdown" class="dropdown-content">
	    <a href="create.php">Create Event</a>
	    <a href="#about">How it Works</a>
	    <a href="#contact">FAQs</a>
	  </div>
	</div>

 <button class="mylocation"><?php echo "$geoplugin->city";?><i class="fa fa-angle-down"></i></button>
<div class="nearby">
	<p>Cities near <?php echo "$geoplugin->city";?></p>
	<?php 

	$nearby = $geoplugin->nearby();

if ( isset($nearby[0]['geoplugin_place']) ) {
	foreach ( $nearby as $key => $array ) {

		echo '<a href="city.php?sel_city='.$array['geoplugin_place'].'"><p>'.$array['geoplugin_place'].'</p></a>';
	}
}

 ?>

</div>
<img class="profileimg" src="<?php echo $_SESSION['picture'] ?>" title="<?php echo $_SESSION['givenName'] ?>">
<div class="mydetails">
	<div class="organiser" style="float: left; border-right: 1px solid #ccc; padding-right: 15px;">
	<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;">Organiser Profile</p>
	<p><b><?php echo $_SESSION['givenName']. ' ' ?><?php echo $_SESSION['familyName'] ?></b></p>
	<p><?php echo $_SESSION['email'] ?></p><br>
	<a href="create.php" target="_blank">Create Event</a>
	<a href="my-events.php" target="_blank">My Events</a>
	<a href="payout-settings.php" target="_blank">Payout Settings</a>
	</div>

	<div class="attendee" style="float: right; padding-right: 15px; text-align: right;">
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;">Attendee Profile</p>
		<p style="padding-bottom: 0px;"><?php echo $_SESSION['givenName']. ' ' ?><?php echo $_SESSION['familyName'] ?></p>
		<p><?php echo $_SESSION['email'] ?></p><br>
		<a href="booking-history.php" target="_blank">Booking History</a>
		<a href="../google-login/logout.php">Logout</a>
	</div>
</div>
</header><br><br><br>

<section>
	<p>Please add a bank account where you want to receive your ticketing Payments.</p>
	
	<h3>Add bank account</h3>
	<form method="POST" action="payout-settings.php">
	  <table>
		<tr><?php echo "$msg"; ?></tr>
		<tr>
		  <td><label for="name">Account Holder Name</label></td>
		  <td><input type="text" name="name" placeholder="e.g. Santosh Koraddi" id="name"></td>
		</tr>

		<tr>
		  <td><label for="account">Account Number</label></td>
		  <td><input type="text" name="account" placeholder="e.g. 40569803214598" id="account"><br></td>
		</tr>

		<tr>
		  <td><label for="ifsc">IFSC Code</label></td>
		  <td><input type="text" name="ifsc" placeholder="e.g. SBI0000123" id="ifsc"><br></td>
		</tr>

		<tr>
		  <td><label for="bank">Bank Name</label></td>
		  <td><input type="text" name="bank" placeholder="e.g. State Bank of India" id="bank"><br></td>
		</tr>

		<tr>
		  <td><label for="email">Email</label></td>
		  <td><input type="email" name="email" placeholder="e.g. santosh@Koraddi.com" id="email"><br></td>
		</tr>

		<tr>
		  <td><label for="phone">Phone Number</label></td>
		  <td><input type="number" name="phone" placeholder="e.g. 9876543210" id="phone"><br></td>
		</tr>
		
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Add"></td>
		</tr>

</table>
	</form>
</section>

<!-- FOOTER PART -->
<footer>
	<a href="about.php" target="_blank">About</a>
	<a href="team.php" target="_blank">Team</a>
	<a href="terms.php" target="_blank">Terms of service</a>
	<a href="privary-policy.php" target="_blank">Privacy Policy</a>
	<a href="pricing.php" target="_blank">Pricing</a>
	<a href="contact.php" target="_blank">Contact us</a>
	<img src="../img/mylogo.png" draggable="false" style="width:130px; float: right; padding-right: 30px;">
	<div class="copyright">
		© Copyright 2019. All Rights Reserved.
	</div>
</footer>

</body>
</html>