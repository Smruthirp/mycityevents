<?php $connect = mysqli_connect("localhost", "root", "", "responses"); ?>
<?php
session_start();

require_once('../location/geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
?>

<!DOCTYPE html>
<html>
<head>
	<title>How it Works | My City Events</title>
<link rel="shortcut icon" href="../img/mylogo.png" type="image/x-icon">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Philosopher" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/style.css">


<script type="text/javascript">
	$(document).ready(function(){
		$('.mylocation').click(function(){
			$('.nearby').toggle();
		});
		$('.profileimg').click(function(){
			$('.mydetails').toggle();
		});
		
	});
</script>
<style type="text/css">
	h2{
		text-transform: uppercase;
		font-size: 18px;
		padding: 5px;
		background-image: linear-gradient(transparent 50%, #f0c1ff 50%);
		display: inline-block;
		margin-bottom: 10px;
	}p{
		padding: 15px;
		word-spacing: 2px;

	}
	ul li{
		list-style-type: lower-roman;
		padding: 5px;
	}
	.loginMe{
		text-decoration: none;
		margin-top: 21px;
		background: #ddd;
		color: #000;
		font-size: 14px;
		text-align: center;
		display: inline-block;
		padding: 7px;
		width: 100px;
		border-radius: 3px;
		margin-left: 20px;
	}

</style>
</head>
<body>

<!-- HEADER PART -->
  <header>
  <a href="../index.php"><img src="../img/mylogo.png" draggable="false" style="width:85px; float: left; padding-left: 15px; height: 60px;"></a>

	<form method="POST">
		<input type="text" name="search" class="event_search" required placeholder="Search an Event, Organiser or Location..">
		<button type="submit" name="submit-search" class="event_submit">Search</button>
	</form>

	<div class="dropdown">
	  <button onclick="myFunction()" class="dropbtn">Organizers<i class="fa fa-angle-down"></i></button>
	  <div id="myDropdown" class="dropdown-content">
	    <a href="create.php" target="_blank">Create Event</a>
	    <a href="how-it-works.php" target="_blank">How it Works</a>
	    <a href="faq.php" target="_blank">FAQs</a>
	  </div>
	</div>

 <button class="mylocation"><?php echo "$geoplugin->city";?><i class="fa fa-angle-down"></i></button>
<div class="nearby">
	<p>Cities near <?php echo "$geoplugin->city";?></p>
	<?php 

	$nearby = $geoplugin->nearby();

if ( isset($nearby[0]['geoplugin_place']) ) {
	foreach ( $nearby as $key => $array ) {

		echo '<a href="city.php?sel_city='.$array['geoplugin_place'].'"><p>'.$array['geoplugin_place'].'</p></a>';
	}
}

 ?>

</div>
<?php


if (!isset($_SESSION['access_token'])) {
	
	echo "<a href='google-login/login.php' class='loginMe'>Login</a>";
	
}else{

echo "
<img class='profileimg' src=".$_SESSION['picture']." title=".$_SESSION['givenName'] .">
<div class='mydetails'>
	<div class='organiser' style='float: left; border-right: 1px solid #ccc; padding-right: 15px;'>
	<p style='border-bottom: 1px solid #ccc; padding-bottom: 10px;'>Organiser Profile</p>
	<p><b>".$_SESSION['givenName']. " ".$_SESSION['familyName']. "</b></p>
	<p>".$_SESSION['email'] ."</p><br>
	<a href='create.php' target='_blank'>Create Event</a>
	<a href='my-events.php' target='_blank'>My Events</a>
	<a href='payout-settings.php' target='_blank'>Payout Settings</a>
	</div>

	<div class='attendee' style='float: right; padding-right: 15px; text-align: right;'>
		<p style='border-bottom: 1px solid #ccc; padding-bottom: 10px;'>Attendee Profile</p>
		<p style='padding-bottom: 0px;'>".$_SESSION['givenName']." ".$_SESSION['familyName']."</p>
		<p>".$_SESSION['email']." </p><br>
		<a href='booking-history.php' target='_blank'>Booking History</a>
		<a href='../google-login/logout.php'>Logout</a>
	</div>
</div>
";}?>

</header><br><br><br><br>

<section>
	<h2>How it works </h2><hr>
	<p>MyCityEvents is a web platform to promote & publish your events to Mass Audience worldwide. You can reach out to your intended audience to showcase your events.</p>
	<ul>
		<li>Lists your event to the MyCityEvents  users and caters your event to the huge traffic on site</li>
		<li>List, promote and sell tickets online</li>
		<li>Provides the user the comfort of booking the ticket at the comfort of his/her couch</li>
		<li>Gives your event the social media exposure</li>
		<li>Increases the reach of your event by circulating newsletters to various clients</li>
		<li>Helps the event organizer to get the best advertising, without making any toil in field</li>
		<li>Assured reliability and complete professional handling of event publicity and ticketing</li>
	</ul>
	<h2>What does the organizer needs to do?</h2><hr>
	<ul>
		<li>Create the Event on MyCityEvents portal, which is a self service portal</li> 
		<li>Choose your payment terms & conditions while creating the Event</li>
		<li>Make the Event Live Immediately</li>
		<li>Start Promoting & Selling the tickets online & Benefits shall be transferred to Organizers accounts as per terms & conditions agreed upon</li>
		<li>Sell your tickets online and keep you posted on all the happenings</li>
		<li>90% of event promotion activity is automated on this Portal</li>

	</ul>
</section>




<script>
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

<!-- FOOTER PART -->
<footer>
	<a href="about.php" target="_blank">About</a>
	<a href="team.php" target="_blank">Team</a>
	<a href="terms.php" target="_blank">Terms of service</a>
	<a href="privary-policy.php" target="_blank">Privacy Policy</a>
	<a href="pricing.php" target="_blank">Pricing</a>
	<a href="contact.php" target="_blank">Contact us</a>
	<img src="../img/mylogo.png" draggable="false" style="width:130px; float: right; padding-right: 30px;">
	<div class="copyright">
		© Copyright 2019. All Rights Reserved.
	</div>
</footer>

</div>
</body>
</html>
